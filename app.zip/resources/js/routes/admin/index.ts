import users from './users'

const admin = {
    users: Object.assign(users, users),
}

export default admin
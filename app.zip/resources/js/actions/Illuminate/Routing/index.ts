import RedirectController from './RedirectController'

const Routing = {
    RedirectController: Object.assign(RedirectController, RedirectController),
}

export default Routing
import UserController from './UserController'

const Admin = {
    UserController: Object.assign(UserController, UserController),
}

export default Admin
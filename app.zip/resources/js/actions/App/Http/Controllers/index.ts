import DashboardController from './DashboardController'
import RequestController from './RequestController'
import TicketController from './TicketController'
import TicketCommentController from './TicketCommentController'
import NotificationController from './NotificationController'
import CategoryController from './CategoryController'
import Admin from './Admin'
import Settings from './Settings'

const Controllers = {
    DashboardController: Object.assign(DashboardController, DashboardController),
    RequestController: Object.assign(RequestController, RequestController),
    TicketController: Object.assign(TicketController, TicketController),
    TicketCommentController: Object.assign(TicketCommentController, TicketCommentController),
    NotificationController: Object.assign(NotificationController, NotificationController),
    CategoryController: Object.assign(CategoryController, CategoryController),
    Admin: Object.assign(Admin, Admin),
    Settings: Object.assign(Settings, Settings),
}

export default Controllers